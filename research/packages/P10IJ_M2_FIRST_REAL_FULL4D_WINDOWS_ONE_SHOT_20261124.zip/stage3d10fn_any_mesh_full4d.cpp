// P10FN: dynamic mesh/shape guard around the unchanged production full4D adjoint.
// The launcher independently checks SHA-pinned approval, resource cap and marker.
#define STAGE3D10DD_FULL4D 1
#define STAGE3D10DK_M1_FULL4D 1  // inherited entrypoint name; NOT a mesh restriction
#define STAGE3D10DL_BOUND_PHYSICAL 1
#include "stage3d10w_analytic_adjoint.cpp"

namespace {
bool supported(int argc,char** argv) {
  if(argc != 16) return false;
  const std::string args[] = {"--p10fn-authorized", "--mesh", "", "--out", "",
    "--mode", "", "--steps", "6", "--dt", "150", "--cutoff-mm", "5",
    "--threads", "4"};
  for(int i=1;i<argc;++i)
    if(i!=3 && i!=5 && i!=7 && i!=9 && i!=11 && std::string(argv[i])!=args[i-1])return false;
  const std::string grid=std::string(argv[9])+"x"+argv[11];
  if(grid!="6x150" && grid!="12x75" && grid!="15x60" &&
     grid!="18x50" && grid!="20x45" && grid!="25x36" &&
     grid!="36x25")return false;
  const std::string mode=argv[7];
  if(mode!="R" && mode!="tz" && mode!="y20")return false;
  const fs::path mesh(argv[3]), out(argv[5]);
  const auto basename=mesh.filename().string();
  if(mesh.extension()!=".msh" || basename.size()<6)return false;
  if(basename[0]!='M' || basename.find_first_not_of("0123456789",1)!=basename.size()-4)
    return false;
  return !out.empty() && out.filename().string().rfind("P10FN_",0)==0;
}
}

int main(int argc,char** argv) {
  if(argc==2 && std::string(argv[1])=="--selftest") {
    const int code=p10dk_inherited_main(argc,argv);
    if(code!=0)return code;
    // P10GY: mandatory dynamic 12/36-step CSV writer selftest, no FEM.
    const auto temp=fs::temp_directory_path()/
      ("P10GY_DYNAMIC_4D_"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
    fs::create_directory(temp);
    try {
      for(const auto grid: {std::pair<int,int>{12,75},std::pair<int,int>{36,25}}){
        std::vector<ice3d::p10dd::Snapshot> a(std::size_t(grid.first));
        std::vector<ice3d::p10dd::Snapshot> b(std::size_t(grid.first));
        ice3d::p10dd::Parts reference{};
        ice3d::p10dd::write_csv(temp,"M1",grid.first,grid.second,a,b,reference);
        std::ifstream csv(temp/"P10DD_SIGNED_R_THETA_PHI_T.csv");
        std::size_t lines=0;std::string line;
        while(std::getline(csv,line))++lines;
        if(lines!=std::size_t(grid.first)*1201+1)return 8;
      }
    }catch(...){fs::remove_all(temp);throw;}
    fs::remove_all(temp);
    std::cout<<"P10GY_DYNAMIC_4D_WRITER_12_36_SELFTEST_OK no_FEM=1\n";
    char* good[]={(char*)"exe",(char*)"--p10fn-authorized",(char*)"--mesh",
      (char*)"M42.msh",(char*)"--out",(char*)"P10FN_SELFTEST",
      (char*)"--mode",(char*)"R",(char*)"--steps",(char*)"6",
      (char*)"--dt",(char*)"150",(char*)"--cutoff-mm",(char*)"5",
      (char*)"--threads",(char*)"4"};
    if(!supported(16,good))return 3;
    good[3]=(char*)"H0.msh";
    if(supported(16,good))return 4;
    good[3]=(char*)"M42.msh";
    good[7]=(char*)"tz";
    if(!supported(16,good))return 5;
    good[7]=(char*)"y20";
    if(!supported(16,good))return 6;
    good[11]=(char*)"300";
    if(supported(16,good))return 7;
    std::cout<<"P10FN_ANY_MESH_GUARD_SELFTEST_OK no_FEM=1\n";
    return 0;
  }
  if(argc==2 && std::string(argv[1])=="--help") {
    std::cout<<"P10FN guarded R|tz|y20: run through verified no-input launcher.\n";
    return 0;
  }
  if(!supported(argc,argv)) {
    std::cerr<<"P10FN_STOP_NO_FEM: unsupported command shape/name/parameters\n";
    return 2;
  }
  const char* marker=std::getenv("P10FN_ONE_SHOT_MARKER");
  if(!marker || !fs::is_regular_file(fs::path(marker)) ||
      fs::path(marker).filename().string()!="P10FN_ONE_SHOT_CONSUMED.json") {
    std::cerr<<"P10FN_STOP_NO_FEM: missing one-shot run marker\n";
    return 2;
  }
  std::vector<char*> filtered{argv[0]};
  for(int i=2;i<argc;++i)filtered.push_back(argv[i]);
  return p10dk_inherited_main(int(filtered.size()),filtered.data());
}
