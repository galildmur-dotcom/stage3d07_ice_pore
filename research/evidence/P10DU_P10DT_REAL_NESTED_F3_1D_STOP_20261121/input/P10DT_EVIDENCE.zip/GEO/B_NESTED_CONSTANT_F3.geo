// P10DN / M2: SOURCE-ONLY continuous field, NOT a Gmsh run authorization.
// M1 source CAD/Threshold is preserved exactly; only Background Field changes.
// Coefficient kappa(x,y,z)=F5 in [0,1]. Target V_M2/V_M1=1-0.2*kappa.
// Target h_M2/h_M1=(1-0.2*kappa)^(1/3) in [0.9283177667,1].
// Relative volume means local target, NOT guaranteed realized Tet10 pairing.
// Cartesian mu^2 guarantees no phi discontinuity at either spherical pole.
nearSize = 0.00042855883184652975;
farSize  = 0.0070524788853066865;
Include "sphere_pore_B6_refined.geo";


Field[3] = MathEval;
Field[3].F = "0.5";
Field[6] = MathEval;
Field[6].F = "F2*(1-0.02*F3)";
Background Field=6;
