// P10GO SOURCE-ONLY surface candidate, never 2D/3D/FEM.
Include "M0_ROTATED.geo";
Background Field = 3;
Mesh.MeshSizeFactor = 0.9378887276834518;
Mesh.Algorithm3D = 10;
Mesh.ElementOrder = 2;
Mesh.HighOrderOptimize = 1;
Mesh.MshFileVersion = 2.2;
Mesh.Binary = 0;
Mesh.Algorithm = 5; // Delaunay surface; Tri6 with order 2
