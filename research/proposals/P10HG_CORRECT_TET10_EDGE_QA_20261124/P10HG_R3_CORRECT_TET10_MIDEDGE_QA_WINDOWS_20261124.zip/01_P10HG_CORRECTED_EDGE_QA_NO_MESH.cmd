@echo off
setlocal
cd /d "%~dp0"
echo P10HG R3: Gmsh Tet10 edge-order correction, NumPy only, source QA, NO mesh/FEM.
py -3 P10HG_edge_order_selftest.py
if errorlevel 1 (
  echo P10HG edge-order selftest STOP.
  pause
  exit /b 2
)
py -3 P10HE_build_view.py
if errorlevel 1 (echo P10HG STOP; send P10HE_SOURCE_ONLY_EVIDENCE.zip.) else (echo P10HG QA PASS; send P10HE_SOURCE_ONLY_EVIDENCE.zip.)
pause
