@echo off
setlocal
cd /d "%~dp0"
echo P10HE: prepare PostView from pinned M1 ONLY. NO 1D/2D/3D mesh; no FEM.
py -3 P10HE_build_view.py
if errorlevel 1 (echo P10HE STOP - send P10HE_SOURCE_ONLY_EVIDENCE.zip.) else (echo P10HE SOURCE POSTVIEW PASS - send evidence.)
pause
