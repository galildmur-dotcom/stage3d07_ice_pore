#!/usr/bin/env python3
"""Independent comparison of original M1 wall vs P10IB 2D-only wall output."""
import io
import json
import sys
from pathlib import Path
from collections import defaultdict

import numpy as np
import p10hy_surface_smoothness_audit as wall
import p10hz_matched_wall_h_audit as matched

C=np.array([0.,0.,.03])
R=.001

def surface2d(raw):
    f=io.StringIO(raw.decode('ascii'))
    nodes={}
    for line in f:
        if line.strip()=='$Nodes':
            n=int(next(f))
            for _ in range(n):
                q=next(f).split()
                nodes[int(q[0])]=[float(v) for v in q[1:]]
    arr=np.zeros((max(nodes)+1,3))
    for i,v in nodes.items():arr[i]=v
    faces=wall.read_faces(raw)
    assert len(faces)>0 and np.max(abs(np.linalg.norm(arr[np.unique(faces)]-C,axis=1)-R))<1e-9
    edges=set();inc=defaultdict(list)
    adj=defaultdict(list);tri_h=[]
    for fi,t in enumerate(faces):
        lengths=[]
        for i,j in ((0,1),(1,2),(2,0)):
            u,v=map(int,(t[i],t[j]));key=tuple(sorted((u,v)))
            p,q=arr[u]-C,arr[v]-C
            h=R*np.arccos(np.clip(np.dot(p,q)/R**2,-1,1))*1000
            lengths.append(h);adj[key].append(fi)
            if key not in edges:
                edges.add(key);inc[u].append(h);inc[v].append(h)
        tri_h.append(np.median(lengths))
    hnode=np.zeros(len(arr))
    for i,v in inc.items():hnode[i]=np.median(v)
    tri_h=np.array(tri_h)
    q=[max(tri_h[pair])/min(tri_h[pair]) for pair in adj.values() if len(pair)==2]
    assert len(q)==3*len(faces)//2
    v=(arr[faces[:,:3]]-C)/R
    geom={'nodes':arr,'faces':faces[:,:3].copy(),'h_node':hnode,'vertices':v,
          'normals':np.cross(v[:,1]-v[:,0],v[:,2]-v[:,0])}
    return geom,{'pore_Tri6':len(faces),'corner_nodes':len(inc),
                 'surface_size_median_mm':float(np.median(tri_h)),
                 'adjacent_surface_h_ratio_p95':float(np.percentile(q,95)),
                 'adjacent_surface_h_ratio_max':float(np.max(q)),
                 'fraction_adjacent_h_ratio_gt_1p25':float(np.mean(np.array(q)>1.25))}

def main():
    m1=matched.surface(Path(sys.argv[1]).read_bytes())
    raw=Path(sys.argv[2]).read_bytes()
    m2,metrics=surface2d(raw)
    src,val=wall.source(Path(sys.argv[3]))
    dirs=matched.fixed_sphere_directions()
    ka=wall.eval_kappa(src,val,C+R*dirs)
    baseline,qa1=matched.evaluate(m1,dirs)
    new,qa2=matched.evaluate(m2,dirs)
    ratio=new/baseline
    masks={'all':np.ones(len(ka),bool),'high_kappa_ge_0p8':ka>=.8,
           'north_polar':dirs[:,2]>=.8,'south_polar':dirs[:,2]<=-.8,
           'low_kappa_lt_0p2':ka<.2}
    metrics['fixed_matched_probe_count']=len(dirs)
    metrics['coverage_M1']=qa1;metrics['coverage_candidate']=qa2
    metrics['matched_h_ratios']={
        name:{'points':int(sel.sum()),'median':float(np.median(ratio[sel])),
              'p05':float(np.percentile(ratio[sel],5)),
              'p95':float(np.percentile(ratio[sel],95)),
              'fraction_refined':float(np.mean(ratio[sel]<1))}
        for name,sel in masks.items()}
    print(json.dumps(metrics,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
