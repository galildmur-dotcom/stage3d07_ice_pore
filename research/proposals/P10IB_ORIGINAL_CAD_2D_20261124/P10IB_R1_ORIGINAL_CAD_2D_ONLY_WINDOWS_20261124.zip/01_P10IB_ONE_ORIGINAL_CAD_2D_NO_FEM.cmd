@echo off
setlocal
cd /d "%~dp0"
echo P10IB: one original CAD 2D pore surface trial only; NO 3D and NO FEM.
where python >nul 2>nul
if errorlevel 1 (
  echo P10IB_STOP: Python was not found. No Gmsh attempt.
  exit /b 2
)
python P10IB_2D_guard.py
set "P10IB_EXIT=%ERRORLEVEL%"
if not "%P10IB_EXIT%"=="0" (
  echo P10IB STOP: return P10IB_GUARD_RESULT.json, P10IB_GMSH_LOG.txt and P10IB_WORKER_ERROR.txt if present.
  exit /b %P10IB_EXIT%
)
echo P10IB COMPLETE: send P10IB_2D_ONLY_EVIDENCE.zip to ChatGPT.
exit /b 0
