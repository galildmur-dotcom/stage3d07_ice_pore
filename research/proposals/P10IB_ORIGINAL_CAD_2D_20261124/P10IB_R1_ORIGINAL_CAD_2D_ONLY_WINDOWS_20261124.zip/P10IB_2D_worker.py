#!/usr/bin/env python3
"""One bounded original-CAD Gmsh4.15.2 2D test; NEVER generate 3D or FEM."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys
import time
import traceback
import zipfile

import numpy as np
import p10hy_surface_smoothness_audit as wall
import p10hz_matched_wall_h_audit as matched
import p10ia_source_only_surface_seed_preflight as seeds
from p10hk_direct_kappa_callback_benchmark import DirectKappa
import p10hc_continuous_kappa_geo as field

HERE=Path(__file__).resolve().parent
ALPHA=.40
SEP_MM=.15
ANY_NODE_GAP_MM=.06
SEAM_GAP_MM=.12
MAX_CALLBACKS=500000
GEO_SHA='f1227074616375c28706e1e55cddde370b9a9fca069aab88513b4313c8239f51'
M1_SHA='47460969be26c2bd0a15e0b1425806fa350aa09aa2b4ac9f80605b433fc65ca7'
CSV_SHA='98bc99af9783e14f7800f08ecd04fc6bee8093d0490b359e3a024f4c6c4566a3'
QA_SHA='361d8812af277505abc59b480042d5b049fb23ae6d664ad781868b985eeafae3'
C=np.array([0.,0.,.03])

def need(x,s):
    if not x:raise RuntimeError("P10IB_STOP: "+s)

def check_sha(name,expected):
    h=hashlib.sha256((HERE/name).read_bytes()).hexdigest()
    need(h==expected,"fingerprint "+name)

def seed_directions(source,values):
    raw=(HERE/'P10GT_HXT10.msh').read_bytes()
    m=matched.surface(raw)
    corners=np.unique(m['faces'])
    nodes=m['nodes']
    existing=(nodes[corners]-C)/.001
    allnodes=(nodes[np.unique(wall.read_faces(raw))]-C)/.001
    dirs=matched.fixed_sphere_directions()
    kap=wall.eval_kappa(source,values,C+.001*dirs)
    dcorner=seeds.nearest_arc_mm(dirs,existing)
    dany=seeds.nearest_arc_mm(dirs,allnodes)
    selected,remain=seeds.select_seeds(dirs,kap,dcorner,SEP_MM,dany,ANY_NODE_GAP_MM)
    need(len(selected)==10,"source-only seed selection differs from pinned P10IA")
    chosen=dirs[selected]
    need(np.all(kap[selected]>=.8),"seed kappa not high")
    need(float(dany[selected].min())>=ANY_NODE_GAP_MM-1e-9,"seed too near old Tri6")
    # Rotated OCC sphere has degenerate CAD poles at y = +/-R.
    poles=np.array([[0.,1.,0.],[0.,-1.,0.]])
    dpoles=seeds.nearest_arc_mm(chosen,poles)
    need(float(dpoles.min())>=SEAM_GAP_MM,"candidate near rotated CAD pole")
    return chosen,kap[selected],dict(
        old_max_gap_mm=float(dcorner[kap>=.8].max()),
        guarded_max_gap_mm=float(remain[kap>=.8].max()),
        min_gap_to_old_all_Tri6_mm=float(dany[selected].min()),
        min_distance_to_CAD_poles_mm=float(dpoles.min()))

def main():
    for n,s in (('P10GT_HXT10.geo',GEO_SHA),
                ('P10GT_HXT10.msh',M1_SHA),
                ('P10HA_SPATIAL_KAPPA_1200_BINS.csv',CSV_SHA),
                ('P10HA_KAPPA_QA.json',QA_SHA)):
        check_sha(n,s)
    source,v25,_,_,_,qa=field.load_centers(
        HERE/'P10HA_SPATIAL_KAPPA_1200_BINS.csv',
        HERE/'P10HA_KAPPA_QA.json')
    d,values=wall.source(HERE/'P10HA_SPATIAL_KAPPA_1200_BINS.csv')
    need(np.max(abs(d-source))<1e-14,"C2 source centers mismatch")
    need(np.max(abs(values-v25))<1e-14,"C2 weights mismatch")
    dirs,kseed,pre=seed_directions(d,values)
    import gmsh
    need(gmsh.__version__=='4.15.2',"Gmsh 4.15.2 exact version required")
    gmsh.initialize()
    try:
        gmsh.option.setNumber('General.Terminal',1)
        gmsh.open(str(HERE/'P10GT_HXT10.geo'))
        need(len(gmsh.model.getEntities(3))==2,"original CAD must contain 2 ice volumes")
        pore=list(map(int,gmsh.model.getEntitiesForPhysicalGroup(2,8)))
        need(pore==[8],"unexpected pore CAD tag")
        need(gmsh.model.getType(2,8)=='Sphere',"pore CAD not OCC sphere")
        need(len(gmsh.model.getBoundary([(2,8)],oriented=False))==2,
             "pore CAD seam contract changed")
        need(abs(gmsh.option.getNumber('Mesh.MeshSizeFactor')-.9378887276834518)<1e-12,
             "pinned background size factor")
        tags=[];coordinates=[]
        for direction in dirs:
            xyz=C+.001*direction
            xyz=list(map(float,xyz))
            projection,uv=gmsh.model.getClosestPoint(2,8,xyz)
            proj=np.asarray(projection).reshape(-1,3)[0]
            need(np.linalg.norm(proj-xyz)<1e-9,"point is not on original sphere")
            need(bool(gmsh.model.isInside(2,8,xyz)),"candidate not inside pore CAD face")
            tags.append(gmsh.model.occ.addPoint(*xyz,meshSize=0))
            coordinates.append(xyz)
        gmsh.model.occ.synchronize()
        need(list(map(int,gmsh.model.getEntitiesForPhysicalGroup(2,8)))==[8],
             "pore physical tag modified by OCC synchronization")
        gmsh.model.mesh.embed(0,tags,2,8)
        direct=DirectKappa(source,v25,qa['mechanical_only_25_36_shared_smoothing_denominator'])
        calls=0;ghost=0;overflow=False
        def cb(dim,tag,x,y,z,lc):
            nonlocal calls,ghost,overflow
            calls+=1
            if calls>MAX_CALLBACKS:
                overflow=True
                return lc
            p=np.array([x,y,z]);diff=p-C;r=np.linalg.norm(diff)
            if r<.001-1e-12:
                ghost+=1
                if r<1e-15:return lc
                p=C+(.001/r)*diff
            k=direct.kappa(*p)
            return lc*(1-ALPHA*k)**(1/3)
        gmsh.model.mesh.setSizeCallback(cb)
        start=time.perf_counter()
        gmsh.model.mesh.generate(2)
        seconds=time.perf_counter()-start
        gmsh.model.mesh.removeSizeCallback()
        need(not overflow,"callback bound exceeded")
        three=gmsh.model.mesh.getElements(3)
        need(sum(map(len,three[1]))==0,"2D-only contract: found 3D elements")
        types,element_tags,_=gmsh.model.mesh.getElements(2,8)
        need(set(map(int,types))=={9},"pore should contain Tri6 only")
        tris=int(sum(map(len,element_tags)))
        coords=[]
        for tag in tags:
            nodeid,xx,_=gmsh.model.mesh.getNodes(0,tag)
            need(len(nodeid)==1,"embedded CAD point missing from output mesh")
            coords.append(xx[:3])
        wallnodes,xyz,_=gmsh.model.mesh.getNodes(2,8,True)
        xyz=np.asarray(xyz).reshape(-1,3)
        r=np.linalg.norm(xyz-C,axis=1)
        need(np.max(abs(r-.001))<1e-8,"pore mesh radial deviation")
        mesh=HERE/'P10IB_SURFACE_ONLY_UNVERIFIED.msh'
        gmsh.write(str(mesh))
        result={'protocol':'P10IB_R1_ORIGINAL_CAD_EMBEDDED_HIGH_KAPPA_2D_ONLY',
                'status':'2D_CANDIDATE_SAVED_PENDING_INDEPENDENT_QA',
                'gmsh_version':gmsh.__version__,'alpha':ALPHA,
                'original_CAD_SHA256':GEO_SHA,'M1_SHA256':M1_SHA,
                'embedded_pore_surface_tag':8,
                'requested_point_count':len(tags),
                'embedded_geometric_point_tags':tags,
                'requested_coordinates_m':coordinates,
                'source_kappa_at_points':list(map(float,kseed)),
                'source_only_seeding':pre,
                'mesh_nodes_on_pore_including_boundary':len(wallnodes),
                'pore_Tri6':tris,'elapsed_2d_s':seconds,
                'callback_count':calls,'ghost_callback_count':ghost,
                'pore_radial_max_abs_error_m':float(np.max(abs(r-.001))),
                'mesh_sha256':hashlib.sha256(mesh.read_bytes()).hexdigest(),
                'mesh_filename':mesh.name,'FEM_attempts':0,'3D_mesh_attempts':0,
                'accepted_M2':False}
        (HERE/'P10IB_WORKER_RESULT.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        print('P10IB_ORIGINAL_CAD_2D_ONLY_COMPLETE_NO_3D_NO_FEM',flush=True)
    finally:
        gmsh.finalize()

if __name__=='__main__':
    try:main()
    except Exception:
        (HERE/'P10IB_WORKER_ERROR.txt').write_text(traceback.format_exc(),encoding='utf-8')
        print('P10IB_WORKER_STOP',flush=True)
        sys.exit(2)
