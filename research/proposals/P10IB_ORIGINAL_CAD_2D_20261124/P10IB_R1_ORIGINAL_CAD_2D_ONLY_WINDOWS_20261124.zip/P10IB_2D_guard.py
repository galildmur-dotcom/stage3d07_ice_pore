#!/usr/bin/env python3
"""P10IB guarded one-shot, one original CAD 2D mesh and compact evidence."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

HERE=Path(__file__).resolve().parent
LOG=HERE/'P10IB_GMSH_LOG.txt'
GUARD=HERE/'P10IB_GUARD_RESULT.json'
EVIDENCE=HERE/'P10IB_2D_ONLY_EVIDENCE.zip'
MARKER=HERE/'P10IB_ONE_2D_ATTEMPT_CONSUMED.marker'
MAX_WALL=180
MAX_PRIVATE=2*1024**3
MAX_LOG=6*1024**2
MAX_MSH=12*1024**2
FILES={
    'P10GT_HXT10.geo':'f1227074616375c28706e1e55cddde370b9a9fca069aab88513b4313c8239f51',
    'P10GT_HXT10.msh':'47460969be26c2bd0a15e0b1425806fa350aa09aa2b4ac9f80605b433fc65ca7',
    'P10HA_SPATIAL_KAPPA_1200_BINS.csv':'98bc99af9783e14f7800f08ecd04fc6bee8093d0490b359e3a024f4c6c4566a3',
    'P10HA_KAPPA_QA.json':'361d8812af277505abc59b480042d5b049fb23ae6d664ad781868b985eeafae3'}

def private_bytes(pid):
    if sys.platform!='win32':return None
    import ctypes
    from ctypes import wintypes
    class PMC(ctypes.Structure):
        _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD)]+[
            (name,ctypes.c_size_t) for name in (
                'PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage',
                'QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage',
                'PagefileUsage','PeakPagefileUsage','PrivateUsage')]
    k=ctypes.windll.kernel32;ps=ctypes.windll.psapi
    k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
    k.OpenProcess.restype=wintypes.HANDLE
    k.CloseHandle.argtypes=[wintypes.HANDLE]
    k.CloseHandle.restype=wintypes.BOOL
    ps.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(PMC),wintypes.DWORD]
    ps.GetProcessMemoryInfo.restype=wintypes.BOOL
    handle=k.OpenProcess(0x0410,False,pid)
    if not handle:return None
    try:
        m=PMC();m.cb=ctypes.sizeof(m)
        if not ps.GetProcessMemoryInfo(handle,ctypes.byref(m),m.cb):return None
        return int(m.PrivateUsage)
    finally:k.CloseHandle(handle)

def main():
    if MARKER.exists():
        print('P10IB_STOP: one-shot marker already exists; do not rerun',flush=True)
        return 2
    for name,sha in FILES.items():
        path=HERE/name
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=sha:
            print('P10IB_STOP: missing/wrong source',name,flush=True)
            return 2
    import gmsh
    if gmsh.__version__!='4.15.2':
        print('P10IB_STOP: Gmsh Python 4.15.2 required',flush=True)
        return 2
    # Exclusive marker: successful source preflight precedes the ONE native attempt.
    with MARKER.open('x',encoding='ascii') as f:
        f.write('P10IB R1 one original-CAD 2D attempt, no 3D/FEM\n')
    start=time.monotonic()
    status='UNKNOWN';code=2;peak=0
    with LOG.open('w',encoding='utf-8') as f:
        proc=subprocess.Popen([sys.executable,str(HERE/'P10IB_2D_worker.py')],cwd=HERE,
                              stdout=f,stderr=subprocess.STDOUT)
        while proc.poll() is None:
            elapsed=time.monotonic()-start
            current=private_bytes(proc.pid)
            if current is not None:peak=max(peak,current)
            if elapsed>MAX_WALL:
                status='STOP_WALL_180S';code=124;proc.kill();proc.wait();break
            if current is not None and current>MAX_PRIVATE:
                status='STOP_PRIVATE_MEMORY_2GIB';code=125;proc.kill();proc.wait();break
            if LOG.stat().st_size>MAX_LOG:
                status='STOP_LOG_6MIB';code=126;proc.kill();proc.wait();break
            time.sleep(.5)
        else:
            code=proc.returncode
            status='WORKER_FINISHED' if code==0 else 'WORKER_STOP'
    if code==0:
        msh=HERE/'P10IB_SURFACE_ONLY_UNVERIFIED.msh'
        if not msh.is_file() or msh.stat().st_size>MAX_MSH:
            status='STOP_MSH_MISSING_OR_OVER_12MIB';code=127
    payload={'protocol':'P10IB_R1_ONE_GUARDED_ORIGINAL_CAD_2D_ONLY',
             'status':status,'exit_code':code,'wall_s':round(time.monotonic()-start,3),
             'peak_private_bytes_observed':peak if sys.platform=='win32' else None,
             'max_wall_s':MAX_WALL,'max_private_bytes':MAX_PRIVATE,
             'max_log_bytes':MAX_LOG,'max_msh_bytes':MAX_MSH,
             'one_shot_consumed':True,'FEM_attempts':0,'3D_mesh_attempts':0,
             'accepted_M2':False}
    GUARD.write_text(json.dumps(payload,indent=2)+'\n',encoding='utf-8')
    if code==0:
        names=['P10IB_GUARD_RESULT.json','P10IB_GMSH_LOG.txt',
               'P10IB_WORKER_RESULT.json','P10IB_SURFACE_ONLY_UNVERIFIED.msh',
               'P10IB_ONE_2D_ATTEMPT_CONSUMED.marker']
        with zipfile.ZipFile(EVIDENCE,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for n in names:z.write(HERE/n,n)
        with zipfile.ZipFile(EVIDENCE) as z:
            assert z.testzip() is None
        print('P10IB_2D_ONLY_COMPLETE_NO_3D_NO_FEM',EVIDENCE,flush=True)
    else:print(status,'send GUARD/LOG/WORKER_ERROR (if present); never rerun same marker',flush=True)
    return 0 if code==0 else 2

if __name__=='__main__':
    try:sys.exit(main())
    except Exception as e:
        print('P10IB_GUARD_STOP',type(e).__name__,str(e),flush=True)
        sys.exit(2)
