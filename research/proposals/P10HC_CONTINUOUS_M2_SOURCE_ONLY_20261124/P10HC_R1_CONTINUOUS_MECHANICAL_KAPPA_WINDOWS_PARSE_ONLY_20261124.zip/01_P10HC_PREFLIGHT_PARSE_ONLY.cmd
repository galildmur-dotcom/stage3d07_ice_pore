@echo off
setlocal
cd /d "%~dp0"
echo P10HC: Gmsh 4.15.2 GEO parse only. NO 2D, NO 3D, NO FEM.
py -3 P10HC_windows_preflight.py
if errorlevel 1 (
  echo P10HC STOP: read P10HC_01_RESULT.txt and send P10HC_01_PARSE_EVIDENCE.zip.
) else (
  echo P10HC SOURCE PARSE PASS. No mesh was generated.
)
pause
