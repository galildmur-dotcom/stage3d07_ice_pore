#!/usr/bin/env python3
"""P10HC Windows native *parse-only*: never calls Gmsh -2/-3 or FEM."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time
import zipfile

HERE=Path(__file__).resolve().parent
GMSH=Path(r'C:\gmsh-4.15.2-Windows64\gmsh.exe')
QA=HERE/'P10HC_SOURCE_FIELD_QA.json'
RESULT=HERE/'P10HC_01_RESULT.txt'
GEO=HERE/'P10HC_M2_SOURCE_ONLY.geo'
LOG=HERE/'P10HC_NATIVE_PARSE.log'
REV='P10HC_R1_SOURCE_ONLY_PARSER_PREFLIGHT_NO_MESH'


def require(flag,msg):
    if not flag:raise RuntimeError('P10HC_STOP: '+msg)


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def evidence():
    path=HERE/'P10HC_01_PARSE_EVIDENCE.zip'
    # source-only evidence; never distribute user's raw M0/M1 meshes/physics.
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name in ('P10HC_01_RESULT.txt','P10HC_NATIVE_PARSE.log',
                     'P10HC_SOURCE_FIELD_QA.json','P10HC_M2_SOURCE_ONLY.geo'):
            p=HERE/name
            if p.exists():z.write(p,name)
    require(zipfile.ZipFile(path).testzip() is None,'self evidence CRC')
    print('P10HC_SEND_EVIDENCE='+str(path),flush=True)


def main():
    report={'revision':REV,'status':'STOP','GMSH_native_parse_attempts':0,
            'GMSH_2D_mesh_attempts':0,'GMSH_3D_mesh_attempts':0,'FEM_attempts':0}
    code=2
    try:
        require(sys.platform=='win32','run only on Windows PC')
        qa=json.loads(QA.read_text(encoding='utf-8'))
        require(qa['protocol']=='P10HC_R1_M1_CAD_CONTINUOUS_MECHANICAL_KAPPA_SOURCE_ONLY',
                'source manifest protocol')
        for name,digest in qa['source_sha256'].items():
            p=HERE/name
            require(p.is_file() and sha(p)==digest,'source hash '+name)
        require(GMSH.is_file(),'Gmsh.exe path missing')
        v=subprocess.run([str(GMSH),'-version'],capture_output=True,text=True,timeout=12)
        require(v.returncode==0 and '4.15.2' in v.stdout,'require exact Gmsh4.15.2')
        report['GMSH_native_parse_attempts']=1
        cmd=[str(GMSH),str(GEO),'-parse_and_exit','-nopopup','-nt','2']
        begin=time.monotonic()
        with LOG.open('wb') as log:
            proc=subprocess.Popen(cmd,cwd=HERE,stdout=log,stderr=subprocess.STDOUT)
            try:exitcode=proc.wait(timeout=180)
            except subprocess.TimeoutExpired:
                proc.kill();proc.wait();raise RuntimeError('native parse timeout 180s')
        report['parse_wall_s']=round(time.monotonic()-begin,3)
        report['native_exit_code']=exitcode
        require(LOG.stat().st_size<=6*1024**2,'native log cap 6MiB')
        last=LOG.read_text(encoding='utf-8',errors='replace')
        require(exitcode==0 and not re.search(r'(?m)^\s*Error\s*:',last),
                'Gmsh native GEO parsing failed; no 2D/3D attempted')
        report['status']='P10HC_GMSH_NATIVE_PARSE_ONLY_PASS'
        code=0
    except Exception as error:
        report['error']=repr(error)
    finally:
        RESULT.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        print(report['status'],flush=True)
        if 'error' in report:print(report['error'],flush=True)
        evidence()
    return code


if __name__=='__main__':sys.exit(main())
