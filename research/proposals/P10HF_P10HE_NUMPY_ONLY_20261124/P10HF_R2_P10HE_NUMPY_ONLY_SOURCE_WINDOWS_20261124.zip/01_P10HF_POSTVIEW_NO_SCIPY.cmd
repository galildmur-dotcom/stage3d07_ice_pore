@echo off
setlocal
cd /d "%~dp0"
echo P10HF R2: NumPy ONLY, no SciPy. Source-only 3D PostView; no mesh and no FEM.
py -3 P10HF_numpy_selftest.py
if errorlevel 1 (
  echo P10HF SELFTEST STOP. Do not run old P10HE; send screen text.
  pause
  exit /b 2
)
py -3 P10HE_build_view.py
if errorlevel 1 (echo P10HF STOP - send P10HE_SOURCE_ONLY_EVIDENCE.zip.) else (echo P10HF source PASS - send P10HE_SOURCE_ONLY_EVIDENCE.zip.)
pause
