@echo off
setlocal
cd /d "%~dp0"
echo P10HD exactly ONE bounded 1D field evaluation. NO -2, -3, FEM.
py -3 P10HD_one_1d.py --one-1d
if errorlevel 1 (echo P10HD STOP - send evidence.) else (echo P10HD 1D PASS - send evidence.)
pause
