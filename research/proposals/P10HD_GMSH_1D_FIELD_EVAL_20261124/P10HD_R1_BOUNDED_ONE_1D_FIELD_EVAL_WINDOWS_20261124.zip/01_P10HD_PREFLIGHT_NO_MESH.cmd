@echo off
setlocal
cd /d "%~dp0"
echo P10HD Native Gmsh parse-only, NO MESH, NO FEM.
py -3 P10HD_one_1d.py --preflight
if errorlevel 1 (echo P10HD STOP - do not run 02.) else (echo P10HD 01 PASS - 02 may run once.)
pause
