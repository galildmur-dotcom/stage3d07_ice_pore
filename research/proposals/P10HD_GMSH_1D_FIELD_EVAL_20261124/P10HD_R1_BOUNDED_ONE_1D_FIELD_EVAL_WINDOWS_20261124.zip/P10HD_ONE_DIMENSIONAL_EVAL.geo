// P10HD: diagnostic physical rays, Gmsh -1 ONLY, never 2D/3D M2/FEM.
// Fixed center (0,0,0.03)m and poreR=0.001m; four ray directions.
SetFactory("Built-in");
Point(1)={0,0,0.031,0.0005};
Point(2)={0,0,0.035,0.0005};
Line(1)={1,2}; // north polar
Point(3)={0,0,0.029,0.0005};
Point(4)={0,0,0.025,0.0005};
Line(2)={3,4}; // south polar
Point(5)={0.001,0,0.03,0.0005};
Point(6)={0.005,0,0.03,0.0005};
Line(3)={5,6}; // equator east
Point(7)={0,0.001,0.03,0.0005};
Point(8)={0,0.005,0.03,0.0005};
Line(4)={7,8}; // equator north
// Field[7] is a constant isolated 1D baseline. The 3D pinned M1 F7 itself
// was already independently checked in P10GT; this test probes P10HC F40..F43.
Field[7] = MathEval;
Field[7].F = "0.0005";
Include "P10HC_CONTINUOUS_KAPPA_FIELDS.geo";
// Stronger diagnostic contrast to force evaluation of F42, not an M2 rule.
Field[44] = MathEval;
Field[44].F = "0.0001+0.0009*(1-F42)";
Background Field = 44;
Mesh.MeshSizeExtendFromBoundary = 0;
Mesh.MeshSizeFromPoints = 0;
Mesh.MeshSizeFromCurvature = 0;
Mesh.MshFileVersion = 2.2;
Mesh.Binary = 0;
